﻿import sqlite3
import random
import string
import hashlib

conn = sqlite3.connect('instance/silo_management.db')
salt = 'smart_silo_salt_2026'

# Get first pending user
pending = conn.execute('SELECT id, full_name, email, phone, preferred_username, requested_role FROM pending_users WHERE status = "pending" LIMIT 1').fetchone()

if pending:
    print(f'Approving: {pending[1]}')
    
    # Generate worker number
    count = conn.execute('SELECT COUNT(*) FROM users WHERE username LIKE "WK-%"').fetchone()[0]
    worker_number = f'WK-{count+1:04d}'
    
    # Generate temporary password
    chars = string.ascii_letters + string.digits + '!@#$'
    temp_pwd = ''.join(random.choice(chars) for _ in range(10))
    hashed = hashlib.sha256((temp_pwd + salt).encode()).hexdigest()
    
    # Insert user
    conn.execute('INSERT INTO users (username, password, email, phone, full_name, role) VALUES (?,?,?,?,?,?)',
                 (worker_number, hashed, pending[2], pending[3], pending[1], pending[5]))
    
    # Update pending status
    conn.execute('UPDATE pending_users SET status = "approved" WHERE id = ?', (pending[0],))
    conn.commit()
    
    print(f'Approved! Username: {worker_number}, Password: {temp_pwd}')
else:
    print('No pending users found')

conn.close()
